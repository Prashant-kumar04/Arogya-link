import React, { useState, useCallback, useMemo } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Activity, Heart, TrendingUp } from "lucide-react";
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import { Button } from "../ui/button";
import { Card } from "../ui/card";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { predictVitals, simulateEmergency, VitalsPayload } from "../../services/api";
import { useHealth } from "../../context/HealthContext";
import { useHealthRealtime } from "../../hooks/useHealthRealtime";
// ✅ FIXED: Use Zustand store for real user (phone-auth), NOT useAuth (email mock)
import useHealthStore from "../../store/useHealthStore";

type StatusLabel = "safe" | "warning" | "critical";

export default function HomeScreen() {
  const navigate = useNavigate();
  // ✅ FIXED: user comes from Zustand (real JWT auth), id will be valid
  const user = useHealthStore((state) => state.user);
  const { health, updateVitals: contextUpdateVitals, updateRiskScore, updateStatus, updateExplanation, addChartPoint } = useHealth();
  const { isConnected, pendingConfirmCheck, confirmCheckCountdown, respondToConfirmCheck } = useHealthRealtime(user?.id);

  const [editVitals, setEditVitals] = useState<VitalsPayload>({});
  const [loading, setLoading] = useState(false);
  const [simulating, setSimulating] = useState(false);

  const healthStatus = useMemo(() => {
    if (health?.status === "critical") return "HEALTH RISK";
    if (health?.status === "warning") return "FATIGUE";
    return "SAFE";
  }, [health?.status]);

  const statusColor = useMemo(() => {
    switch (health?.status) {
      case "critical": return "bg-gradient-to-r from-red-500 to-red-600";
      case "warning": return "bg-gradient-to-r from-yellow-500 to-yellow-600";
      default: return "bg-gradient-to-r from-green-500 to-green-600";
    }
  }, [health?.status]);

  React.useEffect(() => {
    const handleHealthAlert = () => {
      navigate("/dashboard", { state: { activeTab: "emergency" } });
    };
    window.addEventListener("health_alert", handleHealthAlert);
    return () => window.removeEventListener("health_alert", handleHealthAlert);
  }, [navigate]);

  const handlePredict = useCallback(async (source: "manual" | "smartwatch" | "demo" = "manual") => {
    if (!editVitals.age || !editVitals.heart_rate || !editVitals.systolic) {
      alert("Please enter Age, Heart Rate, and Systolic BP");
      return;
    }

    setLoading(true);
    try {
      const res = await predictVitals(editVitals, source);
      updateRiskScore(res.risk_score);
      updateStatus(res.status as StatusLabel);
      updateExplanation(res.explanation);
      contextUpdateVitals(editVitals);
      if (editVitals.heart_rate && editVitals.systolic) {
        addChartPoint(editVitals.heart_rate, editVitals.systolic);
      }
    } catch (err) {
      console.error("Prediction failed", err);
      updateExplanation("Prediction failed. Ensure the AI backend is running on port 8000.");
      updateStatus("warning");
    } finally {
      setLoading(false);
    }
  }, [editVitals, contextUpdateVitals, updateRiskScore, updateStatus, updateExplanation, addChartPoint]);

  const handleSimulate = useCallback(async () => {
    setSimulating(true);
    try {
      const res = await simulateEmergency();
      updateRiskScore(res.risk_score);
      updateStatus(res.status as StatusLabel);
      updateExplanation(res.explanation);
      addChartPoint(res.vitals?.heart_rate ?? 120, res.vitals?.systolic ?? 180);
    } catch (err) {
      console.error("Simulation failed", err);
    } finally {
      setSimulating(false);
    }
  }, [updateRiskScore, updateStatus, updateExplanation, addChartPoint]);

  const updateEditVitals = useCallback((key: keyof VitalsPayload, value: number) => {
    setEditVitals((prev) => ({ ...prev, [key]: value }));
  }, []);

  const hasData = health?.risk_score !== null && health?.status !== null;

  return (
    <div className="max-w-lg mx-auto p-4 space-y-6">
      {/* Welcome */}
      <div className="pt-4">
        <h1 className="text-2xl font-bold text-gray-800">
          Hello, {user?.name || user?.phone || 'Guest'} 👋
        </h1>
        <p className="text-gray-500 text-sm">
          {isConnected ? '🟢 Real-time monitoring active' : '⚪ Enter vitals manually below'}
        </p>
      </div>

      {/* Health Status Card */}
      {hasData && (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className={`rounded-2xl p-6 shadow-xl text-white ${statusColor}`}>
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-4xl font-bold">{healthStatus}</h2>
              <p className="text-sm opacity-90 mt-1">{health?.explanation}</p>
            </div>
            <div className="text-right">
              <p className="text-5xl font-bold">{health?.risk_score?.toFixed(1) ?? "--"}</p>
              <p className="text-xs opacity-80">Risk Score</p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Confirm Check Modal */}
      {pendingConfirmCheck && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-orange-50 border-2 border-orange-400 rounded-2xl p-5 shadow-lg"
        >
          <h3 className="font-bold text-orange-800 text-lg mb-2">⚠️ Health Check Required</h3>
          <p className="text-orange-700 text-sm mb-4">Are you feeling okay? Respond within {confirmCheckCountdown}s</p>
          <div className="flex gap-3">
            <Button className="flex-1 bg-green-500 hover:bg-green-600 text-white rounded-xl" onClick={() => respondToConfirmCheck(true)}>
              ✅ I'm Fine
            </Button>
            <Button className="flex-1 bg-red-500 hover:bg-red-600 text-white rounded-xl" onClick={() => respondToConfirmCheck(false)}>
              🆘 Need Help
            </Button>
          </div>
        </motion.div>
      )}

      {/* Manual Input Card */}
      <Card className="p-5 border border-purple-100">
        <p className="font-bold text-gray-800 mb-3">Manual Vitals Input</p>
        <div className="grid grid-cols-2 gap-3 mt-3">
          <Field label="Age" value={editVitals.age} onChange={(v) => updateEditVitals("age", v)} />
          <Field label="Heart Rate (BPM)" value={editVitals.heart_rate} onChange={(v) => updateEditVitals("heart_rate", v)} />
          <Field label="Systolic BP" value={editVitals.systolic} onChange={(v) => updateEditVitals("systolic", v)} />
          <Field label="Diastolic BP" value={editVitals.diastolic} onChange={(v) => updateEditVitals("diastolic", v)} />
        </div>
        <div className="grid grid-cols-2 gap-3 mt-4">
          <Button className="bg-blue-600 text-white rounded-xl" onClick={() => handlePredict("manual")} disabled={loading}>
            {loading ? "Analyzing..." : "Analyze Risk"}
          </Button>
          <Button className="bg-orange-500 text-white rounded-xl" onClick={handleSimulate} disabled={simulating}>
            {simulating ? "Simulating..." : "Simulate Emergency"}
          </Button>
        </div>
      </Card>

      {/* Chart */}
      {health?.chartData && health.chartData.length > 0 && (
        <Card className="p-5 border border-blue-100">
          <p className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-500" />
            Live Trend
          </p>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={health.chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="time" stroke="#9ca3af" fontSize={10} />
              <YAxis stroke="#9ca3af" fontSize={10} />
              <Tooltip contentStyle={{ borderRadius: '12px', border: '1px solid #e5e7eb' }} />
              <Area type="monotone" dataKey="heartRate" stroke="#ef4444" fill="#fee2e2" strokeWidth={2} name="Heart Rate" />
              <Area type="monotone" dataKey="bp" stroke="#3b82f6" fill="#dbeafe" strokeWidth={2} name="BP" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
      )}
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value?: number | null; onChange: (v: number) => void }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs text-gray-600">{label}</Label>
      <Input type="number" value={value ?? ""} onChange={(e) => onChange(Number(e.target.value))} className="rounded-xl text-sm" />
    </div>
  );
}