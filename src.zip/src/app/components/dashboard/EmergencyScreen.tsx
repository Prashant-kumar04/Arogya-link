import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Phone, Plus, Trash2, AlertTriangle } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';

interface Contact {
  id: number;
  name: string;
  phone: string;
}

const STORAGE_KEY = 'emergency_contacts';

export default function EmergencyScreen() {
  // ✅ FIXED: Start with empty contacts, persist to localStorage
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [showAdd, setShowAdd] = useState(false);

  // Load persisted contacts
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setContacts(JSON.parse(saved));
      }
    } catch (err) {
      console.error('Failed to load emergency contacts:', err);
    }
  }, []);

  const saveContacts = (updated: Contact[]) => {
    setContacts(updated);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (err) {
      console.error('Failed to save emergency contacts:', err);
    }
  };

  const addContact = () => {
    if (!newName.trim() || !newPhone.trim()) return;
    if (contacts.length >= 3) return;
    const updated = [...contacts, { id: Date.now(), name: newName.trim(), phone: newPhone.trim() }];
    saveContacts(updated);
    setNewName('');
    setNewPhone('');
    setShowAdd(false);
  };

  const deleteContact = (id: number) => {
    saveContacts(contacts.filter(c => c.id !== id));
  };

  const testAlert = () => {
    if (contacts.length === 0) {
      alert('Please add at least one emergency contact first.');
      return;
    }
    alert(`🚨 Emergency Alert Simulation\n\nMessage: "HEALTH ALERT - User needs immediate assistance."\n\nWould be sent to:\n${contacts.map(c => `• ${c.name} (${c.phone})`).join('\n')}`);
  };

  return (
    <div className="max-w-lg mx-auto p-4 space-y-6">
      {/* Header */}
      <div className="pt-4">
        <h1 className="text-3xl font-bold text-gray-800">Emergency Contacts</h1>
        <p className="text-gray-500 text-sm">Auto-alert on health risk detected</p>
      </div>

      {/* Alert Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl p-5 shadow-lg text-white"
      >
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-bold mb-1">Automatic Emergency Alert</h3>
            <p className="text-sm opacity-90">
              Alerts are sent to your contacts when health risk is detected. Add up to 3 trusted contacts.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Contacts List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-gray-800">Emergency Contacts ({contacts.length}/3)</h3>
          {contacts.length < 3 && (
            <Button
              onClick={() => setShowAdd(!showAdd)}
              className="bg-blue-500 hover:bg-blue-600 text-white rounded-xl"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          )}
        </div>

        {/* Add Contact Form */}
        {showAdd && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="bg-white rounded-2xl p-5 shadow-lg border border-blue-100"
          >
            <h4 className="font-semibold text-gray-800 mb-3">Add New Contact</h4>
            <div className="space-y-3">
              <div>
                <Label htmlFor="em-name">Name</Label>
                <Input
                  id="em-name"
                  placeholder="Contact name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="mt-1 rounded-xl"
                />
              </div>
              <div>
                <Label htmlFor="em-phone">Phone Number</Label>
                <Input
                  id="em-phone"
                  placeholder="+91 9876543210"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  className="mt-1 rounded-xl"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={addContact}
                  disabled={!newName.trim() || !newPhone.trim()}
                  className="flex-1 bg-green-500 hover:bg-green-600 text-white rounded-xl"
                >
                  Save
                </Button>
                <Button
                  onClick={() => {
                    setShowAdd(false);
                    setNewName('');
                    setNewPhone('');
                  }}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Empty State */}
        {contacts.length === 0 && !showAdd && (
          <div className="bg-gray-50 rounded-2xl p-8 text-center border border-dashed border-gray-200">
            <Phone className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">No emergency contacts added yet.</p>
            <p className="text-gray-400 text-xs mt-1">Tap "Add" to add your first contact.</p>
          </div>
        )}

        {/* Contacts */}
        {contacts.map((contact, index) => (
          <motion.div
            key={contact.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-2xl p-4 shadow-lg border border-gray-100"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-gray-800 truncate">{contact.name}</h4>
                <p className="text-sm text-gray-500">{contact.phone}</p>
              </div>
              <button
                onClick={() => deleteContact(contact.id)}
                className="p-2 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-5 h-5 text-red-500" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Test Alert Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Button
          onClick={testAlert}
          className="w-full h-14 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white rounded-xl shadow-lg text-lg font-semibold"
        >
          <AlertTriangle className="w-5 h-5 mr-2" />
          Test Emergency Alert
        </Button>
      </motion.div>

      {/* Info */}
      <div className="bg-blue-50 rounded-2xl p-4 border border-blue-100">
        <p className="text-sm text-gray-700">
          <strong>How it works:</strong> When your health status reaches "HEALTH RISK",
          automatic alerts are sent to all emergency contacts with your vital signs data.
        </p>
      </div>
    </div>
  );
}
